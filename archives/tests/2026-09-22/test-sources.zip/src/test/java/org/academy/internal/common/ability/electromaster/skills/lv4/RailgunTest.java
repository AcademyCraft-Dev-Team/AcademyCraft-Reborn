package org.academy.internal.common.ability.electromaster.skills.lv4;

import net.minecraft.resources.Identifier;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RailgunTest {
    @Test
    void vanillaFallbackAcceptsIronAmmunitionTiers() {
        assertTrue(Railgun.isVanillaAmmoId(Identifier.withDefaultNamespace("iron_ingot")));
        assertTrue(Railgun.isVanillaAmmoId(Identifier.withDefaultNamespace("iron_block")));
        assertTrue(Railgun.isVanillaAmmoId(Identifier.withDefaultNamespace("anvil")));
        assertTrue(Railgun.isVanillaAmmoId(Identifier.withDefaultNamespace("chipped_anvil")));
        assertTrue(Railgun.isVanillaAmmoId(Identifier.withDefaultNamespace("damaged_anvil")));
        assertFalse(Railgun.isVanillaAmmoId(Identifier.withDefaultNamespace("stick")));
    }

    @Test
    void ammunitionProfilesScaleChargeBeamRangeAndDamage() {
        assertEquals(0, Railgun.AmmoKind.COIN.minimumChargeTicks());
        assertEquals(1.0f, Railgun.AmmoKind.COIN.beamWidthMultiplier());
        assertEquals(48.0f, Railgun.AmmoKind.COIN.beamLength());
        assertEquals(0.8f, Railgun.AmmoKind.COIN.damageMultiplier());

        assertEquals(10, Railgun.AmmoKind.IRON_INGOT.minimumChargeTicks());
        assertEquals(1.5f, Railgun.AmmoKind.IRON_INGOT.beamWidthMultiplier());
        assertEquals(56.0f, Railgun.AmmoKind.IRON_INGOT.beamLength());
        assertEquals(1.0f, Railgun.AmmoKind.IRON_INGOT.damageMultiplier());

        assertEquals(20, Railgun.AmmoKind.IRON_BLOCK.minimumChargeTicks());
        assertEquals(2.0f, Railgun.AmmoKind.IRON_BLOCK.beamWidthMultiplier());
        assertEquals(64.0f, Railgun.AmmoKind.IRON_BLOCK.beamLength());
        assertEquals(1.5f, Railgun.AmmoKind.IRON_BLOCK.damageMultiplier());

        assertEquals(30, Railgun.AmmoKind.ANVIL.minimumChargeTicks());
        assertEquals(2.5f, Railgun.AmmoKind.ANVIL.beamWidthMultiplier());
        assertEquals(72.0f, Railgun.AmmoKind.ANVIL.beamLength());
        assertEquals(2.0f, Railgun.AmmoKind.ANVIL.damageMultiplier());
    }

    @Test
    void damageKeepsTheReferenceBaseAndUsesPlayerScaling() {
        assertEquals(150.0f, Railgun.calculateDamage(1.0f, 1.0f));
        assertEquals(337.5f, Railgun.calculateDamage(1.5f, 1.5f));
        assertEquals(0.0f, Railgun.calculateDamage(-1.0f, 1.0f));
    }

    @Test
    void ammunitionKeepsDamageAndBlockDestructionRadiiSeparate() {
        float[] damage = {2, 3, 4, 5};
        float[] destruction = {1, 1.5f, 2, 2.5f};
        for (var ammo : Railgun.AmmoKind.values()) {
            assertEquals(damage[ammo.ordinal()], ammo.damageRadius());
            assertEquals(destruction[ammo.ordinal()], ammo.destructionRadius());
        }
    }
}
