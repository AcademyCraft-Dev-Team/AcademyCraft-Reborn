package org.academy.internal.common.ability.aeromanip.skills.lv1;

import net.minecraft.world.phys.Vec3;
import org.academy.internal.common.ability.aeromanip.AeromanipChargeTier;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AirflowJetTest {
    @Test
    void vectorTravelAccumulatesAsMaceFallMomentum() {
        assertEquals(7.0, AirflowJet.Server.accumulateMaceMomentum(
                2.0,
                5.0,
                new Vec3(0.0, 0.0, 2.0)
        ));
        assertEquals(4.0, AirflowJet.Server.accumulateMaceMomentum(
                4.0,
                1.0,
                new Vec3(Double.NaN, 0.0, 0.0)
        ));
    }

    @Test
    void chargeMilestonesImproveTheMatchingReleaseTier() {
        assertEquals(4.0f, AirflowJet.INSTANT_AIR_COST);
        assertEquals(8.0f, AirflowJet.HALF_AIR_COST);
        assertEquals(16.0f, AirflowJet.FULL_AIR_COST);
        assertEquals(1.5, AirflowJet.instantDamage(false), 1.0E-9);
        assertEquals(2.0, AirflowJet.instantDamage(true), 1.0E-9);
        assertEquals(1.35, AirflowJet.halfLaunchSpeed(false), 1.0E-9);
        assertEquals(1.62, AirflowJet.halfLaunchSpeed(true), 1.0E-9);
        assertEquals(30, AirflowJet.fullPropulsionDuration(false));
        assertEquals(40, AirflowJet.fullPropulsionDuration(true));
    }

    @Test
    void fullFluidSubmersionReducesFullChargePropulsionSpeed() {
        assertEquals(2.35, AirflowJet.fullPropulsionSpeed(false, false), 1.0E-9);
        assertEquals(2.82, AirflowJet.fullPropulsionSpeed(true, false), 1.0E-9);
        assertEquals(0.94, AirflowJet.fullPropulsionSpeed(false, true), 1.0E-9);
    }

    @Test
    void bufferedChargeInputRetainsItsPressAndReleaseTiming() {
        var held = AirflowJet.Server.BufferedChargeInput.pressed(100L);
        assertFalse(held.isReleased());

        var released = held.release(110L);
        assertTrue(released.isReleased());
        assertEquals(10L, released.chargeTicks());
        assertEquals(AeromanipChargeTier.HALF, released.releaseTier());
        assertSame(released, released.release(130L));
    }
}
