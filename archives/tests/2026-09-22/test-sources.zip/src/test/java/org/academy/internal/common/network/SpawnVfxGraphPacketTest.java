package org.academy.internal.common.network;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import io.netty.buffer.Unpooled;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import org.junit.jupiter.api.Test;

import java.util.Map;

class SpawnVfxGraphPacketTest {
    private static SpawnVfxGraphPacket roundTrip(SpawnVfxGraphPacket packet) {
        var buf = Unpooled.buffer();
        SpawnVfxGraphPacket.CODEC.encode(buf, packet);
        return SpawnVfxGraphPacket.CODEC.decode(buf);
    }

    @Test
    void codecRoundTripsAllFields() {
        var packet = new SpawnVfxGraphPacket(
                Identifier.fromNamespaceAndPath("academy", "vfxgraph/minimal_burst"),
                new Vec3(1.5, -2.0, 3.25), new Vec3(0.25, 0.5, -1.0),
                new Vec3(1.0, 0.0, 0.0), -1, 1.5f, 2.25f,
                Map.of("size", 0.35f, "radius", 8f)
        );

        var decoded = roundTrip(packet);

        assertEquals(packet.assetId(), decoded.assetId());
        assertEquals(packet.position().x, decoded.position().x, 1e-6f);
        assertEquals(packet.position().y, decoded.position().y, 1e-6f);
        assertEquals(packet.position().z, decoded.position().z, 1e-6f);
        assertEquals(packet.direction().x, decoded.direction().x, 1e-6f);
        assertEquals(packet.direction().y, decoded.direction().y, 1e-6f);
        assertEquals(packet.direction().z, decoded.direction().z, 1e-6f);
        assertEquals(packet.localXDirection().x, decoded.localXDirection().x, 1e-6f);
        assertEquals(packet.localXDirection().y, decoded.localXDirection().y, 1e-6f);
        assertEquals(packet.localXDirection().z, decoded.localXDirection().z, 1e-6f);
        assertEquals(packet.followEntityId(), decoded.followEntityId());
        assertEquals(packet.scale(), decoded.scale(), 1e-6f);
        assertEquals(packet.lifetimeSeconds(), decoded.lifetimeSeconds(), 1e-6f);
        assertEquals(packet.floatParams(), decoded.floatParams());
    }

    @Test
    void codecRoundTripsFollowEntityAndEmptyParams() {
        var packet = new SpawnVfxGraphPacket(
                Identifier.fromNamespaceAndPath("academy", "vfxgraph/demo_burst"),
                new Vec3(0, 64, 0), new Vec3(0, 1, 0), 42, 1f, 3f, Map.of()
        );

        var decoded = roundTrip(packet);

        assertEquals(42, decoded.followEntityId());
        assertEquals(Vec3.ZERO, decoded.localXDirection());
        assertEquals(Map.of(), decoded.floatParams());
    }

    @Test
    void orientedRotationKeepsBladeWidthHorizontal() {
        var rotation = SpawnVfxGraphPacket.orientedRotation(
                new Vec3(1.0, 0.0, 0.0), new Vec3(0.0, 0.0, 1.0));

        var forward = rotation.transform(new Vector3f(0f, 1f, 0f));
        var right = rotation.transform(new Vector3f(1f, 0f, 0f));

        assertEquals(1.0f, forward.x, 1.0e-5f);
        assertEquals(0.0f, forward.y, 1.0e-5f);
        assertEquals(0.0f, forward.z, 1.0e-5f);
        assertEquals(0.0f, right.x, 1.0e-5f);
        assertEquals(0.0f, right.y, 1.0e-5f);
        assertEquals(1.0f, right.z, 1.0e-5f);
    }

    @Test
    void longBoltsReachObserversNearTheMiddleAndEndWithoutBroadcastingBeyondTheSegment() {
        var packet = new SpawnVfxGraphPacket(Identifier.fromNamespaceAndPath("academy", "vfxgraph/arc_generate"),
                new Vec3(0, 80, 0), new Vec3(0, 0, 1), -1, 2, 1.25f, Map.of("length", 256f));
        assertEquals(9, packet.distanceToEffectSquared(new Vec3(3, 80, 256)), 0.0001);
        assertEquals(25, packet.distanceToEffectSquared(new Vec3(0, 85, 512)), 0.0001);
        assertEquals(10000, packet.distanceToEffectSquared(new Vec3(0, 80, 612)), 0.0001);
        assertEquals(100, packet.distanceToEffectSquared(new Vec3(0, 80, -10)), 0.0001);
    }

    @Test
    void clientHandlerInitializationIsIdempotent() throws ReflectiveOperationException {
        SpawnVfxGraphPacket.initClient();
        SpawnVfxGraphPacket.initClient();

        var initialized = SpawnVfxGraphPacket.class.getDeclaredField("clientInitialized");
        initialized.setAccessible(true);
        assertTrue(initialized.getBoolean(null));
    }
}
